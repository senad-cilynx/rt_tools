import os
import random
from datetime import datetime, timedelta
from textwrap import dedent
from time import sleep

from impacket.dcerpc.v5 import tsch
from impacket.dcerpc.v5.dtypes import NULL
from impacket.dcerpc.v5.rpcrt import RPC_C_AUTHN_LEVEL_PKT_PRIVACY

from nxc.helpers.misc import gen_random_string
from nxc.helpers.rpc import NXCRPCConnection


class TSCH_EXEC:
    def __init__(self, connection, logger=None, tries=None, share=None,
                 # These options are used by the schtask_as module, except the run_task_as
                 # that defaults to NT AUTHORITY\System user (SID S-1-5-18) if not specified
                 run_task_as="S-1-5-18", run_cmd=None, output_filename=None, task_name=None, output_file_location=None):
        self.__connection = connection
        self.logger = logger
        self.__tries = tries
        self.__share = share
        self.__outputBuffer = b""
        self.__retOutput = False
        self.__output_filename = None

        # Optional args for finetuning the task execution, e.g. used in nxc/modules/schtask_as.py
        self.task_name = task_name if task_name else gen_random_string(8)
        self.run_task_as = run_task_as
        self.run_cmd = run_cmd
        self.output_filename = output_filename
        self.output_file_location = output_file_location

    def execute(self, command, output=False):
        self.__retOutput = output
        self.execute_handler(command)
        return self.__outputBuffer

    def output_callback(self, data):
        self.__outputBuffer = data

    def get_end_boundary(self):
        # Get current date and time + 1 day
        end_boundary = datetime.now() + timedelta(days=1)

        # Format it to match the format in the XML: "YYYY-MM-DDTHH:MM:SS.ssssss"
        return end_boundary.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3]

    def gen_xml(self, command):
        # Random setting order to help with detection
        settings = [
            "       <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>",
            "       <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>",
            "       <AllowHardTerminate>true</AllowHardTerminate>",
            "       <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>",
            "       <RunOnlyIfNetworkAvailable>false</RunOnlyIfNetworkAvailable>"
        ]
        random.shuffle(settings)
        randomized_settings = "\n".join(settings)
        settings2 = [
            "       <AllowStartOnDemand>true</AllowStartOnDemand>",
            "       <Hidden>true</Hidden>",
            "       <Enabled>true</Enabled>",
            "       <RunOnlyIfIdle>false</RunOnlyIfIdle>",
            "       <WakeToRun>false</WakeToRun>",
            "       <Priority>7</Priority>",
            "       <ExecutionTimeLimit>P3D</ExecutionTimeLimit>"
        ]
        random.shuffle(settings2)
        randomized_settings2 = "\n".join(settings2)
        idleSettings = [
            "         <StopOnIdleEnd>true</StopOnIdleEnd>",
            "         <RestartOnIdle>false</RestartOnIdle>"
        ]
        random.shuffle(idleSettings)
        randomized_idleSettings = "\n".join(idleSettings)

        random_cmd_path = [
            "cmd",
            "cmd.exe",
            "C:\\Windows\\System32\\cmd",
            "C:\\Windows\\System32\\cmd.exe",
            "C:\\Windows\\System32\\..\\System32\\cmd",
            "C:\\Windows\\System32\\..\\System32\\cmd.exe",
            "C:\\Windows\\..\\Windows\\System32\\cmd",
            "C:\\Windows\\..\\Windows\\System32\\cmd.exe",
        ]
        cmd_path = random.choice(random_cmd_path)
        random_cmd_arg = ["/c", "/C", "/Q /c", "/F:ON /c", "/T:fg /c", "/T:fg /Q /C", "/F:ON /Q /C"]
        full_command = f"{random.choice(random_cmd_arg)} {command}"

        xml = f"""<?xml version="1.0" encoding="UTF-16"?>
        <Task version="1.3" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
        <Triggers>
           <RegistrationTrigger>
           <EndBoundary>{self.get_end_boundary()}</EndBoundary>
           </RegistrationTrigger>
        </Triggers>
        <Principals>
           <Principal id="LocalSystem">
           <UserId>{self.run_task_as}</UserId>
           <RunLevel>HighestAvailable</RunLevel>
           </Principal>
        </Principals>
        <Settings>
           {randomized_settings}
           <IdleSettings>
           {randomized_idleSettings}
           </IdleSettings>
           {randomized_settings2}
        </Settings>
        <Actions Context="LocalSystem">
           <Exec>
           <Command>{cmd_path}</Command>
        """

        if self.__retOutput:
            file_location = "\\Windows\\Temp\\" if self.output_file_location is None else self.output_file_location
            if self.output_filename is None:
                self.__output_filename = os.path.join(file_location, gen_random_string(8))
            else:
                self.__output_filename = os.path.join(file_location, self.output_filename)
            argument_xml = f"      <Arguments>{full_command} &gt; {self.__output_filename} 2&gt;&amp;1</Arguments>"

        elif self.__retOutput is False:
            argument_xml = f"      <Arguments>{full_command}</Arguments>"

        self.logger.debug("Generated argument XML: " + argument_xml)
        xml += argument_xml

        xml += """
            </Exec>
        </Actions>
        </Task>
        """

        # Removing identation for the final XML file
        return dedent(xml)

    def execute_handler(self, command):
        dce = NXCRPCConnection(self.__connection).connect(r"\atsvc", tsch.MSRPC_UUID_TSCHS, auth_level=RPC_C_AUTHN_LEVEL_PKT_PRIVACY)

        xml = self.gen_xml(command)
        self.logger.debug(f"Task XML: {xml}")
        self.logger.info(f"Creating task \\{self.task_name}")
        try:
            tsch.hSchRpcRegisterTask(dce, f"\\{self.task_name}", xml, tsch.TASK_CREATE, NULL, tsch.TASK_LOGON_NONE)
        except Exception as e:
            if e.error_code and hex(e.error_code) == "0x80070005":
                self.logger.fail("Task scheduling was blocked.")
            elif e.error_code and hex(e.error_code) == "0x80070534":
                self.logger.fail(f"User {self.run_task_as} does not have a valid winstation, cannot run the task on its behalf.")
            else:
                self.logger.fail(str(e))
            return

        # Win2025+ (build 26100): RegistrationTrigger does not start the task over remote TSCH.
        if self.__connection.server_os_build and int(self.__connection.server_os_build) >= 26100:
            try:
                tsch.hSchRpcRun(dce, f"\\{self.task_name}")
            except tsch.DCERPCSessionError as e:
                self.logger.debug(f"hSchRpcRun returned: {e}")

        done = False
        while not done:
            self.logger.debug(f"Calling SchRpcGetLastRunInfo for \\{self.task_name}")
            try:
                resp = tsch.hSchRpcGetLastRunInfo(dce, f"\\{self.task_name}")
            except tsch.DCERPCSessionError as e:
                if e.error_code == 0x00041303:
                    sleep(2)
                    continue
                self.logger.fail(f"Error retrieving task last run info: {e}")
                break
            if resp["pLastRuntime"]["wYear"] != 0:
                done = True
            else:
                sleep(2)

        self.logger.info(f"Deleting task \\{self.task_name}")
        tsch.hSchRpcDelete(dce, f"\\{self.task_name}")

        if self.__retOutput:
            tries = 1
            # Give the command a bit of time to execute before we try to read the output, 0.4 seconds was good in testing
            sleep(0.4)
            while True:
                try:
                    self.logger.info(f"Attempting to read {self.__share}\\{self.__output_filename}")
                    self.__connection.conn.getFile(self.__share, self.__output_filename, self.output_callback)
                    break
                except Exception as e:
                    if tries >= self.__tries:
                        self.logger.fail("ATEXEC: Could not retrieve output file, it may have been detected by AV. Please increase the number of tries with the option '--get-output-tries'. If it is still failing, try the 'wmi' protocol or another exec method")
                        break
                    if "STATUS_BAD_NETWORK_NAME" in str(e):
                        self.logger.fail(f"ATEXEC: Getting the output file failed - target has blocked access to the share: {self.__share} (but the command may have executed!)")
                        break
                    elif "STATUS_VIRUS_INFECTED" in str(e):
                        self.logger.fail("Command did not run because a virus was detected")
                        break
                    # When executing PowerShell and the command is still running, we get a sharing violation
                    # We can use that information to wait longer than if the file is not found (probably av or something)
                    if "STATUS_SHARING_VIOLATION" in str(e):
                        self.logger.info(f"File {self.__share}\\{self.__output_filename} is still in use with {self.__tries - tries} tries left, retrying...")
                        tries += 1
                        sleep(1)
                    elif "STATUS_OBJECT_NAME_NOT_FOUND" in str(e):
                        self.logger.info(f"File {self.__share}\\{self.__output_filename} not found with {self.__tries - tries} tries left, deducting 10 tries and retrying...")
                        tries += 10
                        sleep(1)
                    else:
                        self.logger.debug(f"Exception when trying to read output file: {e!s}. {self.__tries - tries} tries left, retrying...")
                        tries += 1
                        sleep(1)
            try:
                self.logger.debug(f"Deleting file {self.__share}\\{self.__output_filename}")
                self.__connection.conn.deleteFile(self.__share, self.__output_filename)
            except Exception:
                pass

        dce.disconnect()
